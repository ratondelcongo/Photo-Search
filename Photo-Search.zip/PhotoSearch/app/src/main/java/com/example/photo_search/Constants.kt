package com.example.photo_search

const val API_KEY = "3b4138982736674ef2f8e98486d1c4c6"

const val API_SEARCH = "flickr.photos.search"
const val API_GET_RECENT = "flickr.photos.getRecent"
const val API_GET_INFO = "flickr.photos.getInfo"

const val API_BASE_URL = "https://www.flickr.com/services/rest/"
const val API_RESULT_URL = "https://live.staticflickr.com"